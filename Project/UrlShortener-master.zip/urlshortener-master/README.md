# Project Descriptions and screenshots are given here
https://docs.google.com/document/d/1VX7L4ltz7vvXViZ8cz4-8CvZtHEhNsTuKa2IbLOPoig/edit
