# django-banking

You can find the project details and screenshots from the below link
https://docs.google.com/document/d/17sIu_P5cFcyc8nqdtlSed5Bb42IQFkMRjXr38q46UiI/edit?usp=sharing
